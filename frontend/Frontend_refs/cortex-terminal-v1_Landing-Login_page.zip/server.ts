import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialize Gemini client to avoid crashes if the key isn't provided at boot
let aiClient: GoogleGenAI | null = null;
function getAi(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("WARNING: GEMINI_API_KEY is not defined in the environment. Falling back to local simulation engines.");
      throw new Error("GEMINI_API_KEY is required");
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// Simulated data helpers (for offline testing or high-fidelity visualizations)
const GENERATED_ASSETS: Record<string, { name: string, price: number, change: number, history: number[], high: number, low: number, volume: string, cap: string }> = {
  CTX: { name: "Cortex AI Core", price: 341.25, change: 12.4, history: [310, 312, 318, 315, 324, 330, 341.25], high: 345.00, low: 308.50, volume: "1.2B CTX", cap: "$68.2B" },
  BTC: { name: "Bitcoin Core", price: 98450.00, change: 2.1, history: [97100, 96800, 98200, 97900, 98100, 97500, 98450.00], high: 99100.00, low: 96400.00, volume: "24.5K BTC", cap: "$1.95T" },
  ETH: { name: "Ethereum Core", price: 3420.50, change: -1.3, history: [3480, 3450, 3440, 3495, 3460, 3410, 3420.50], high: 3512.00, low: 3390.00, volume: "185.2K ETH", cap: "$412.4B" },
  TSLA: { name: "Tesla Labs", price: 212.80, change: 4.8, history: [198, 201, 205, 202, 209, 210, 212.80], high: 215.10, low: 196.20, volume: "12.4M TSLA", cap: "$678.5B" },
  NVDA: { name: "Nvidia Neural", price: 127.45, change: 8.2, history: [115, 118, 120, 119, 124, 125, 127.45], high: 129.00, low: 114.50, volume: "28.1M NVDA", cap: "$3.12T" },
  AAPL: { name: "Apple Core", price: 178.60, change: -0.4, history: [179.5, 180.1, 178.9, 179.2, 177.5, 178.1, 178.60], high: 181.20, low: 176.80, volume: "8.4M AAPL", cap: "$2.78T" }
};

// Access Approval Engine using Gemini (Interactive Invitation-only setup)
app.post("/api/terminal/request-access", async (req, res) => {
  const { name, bio, targetRole, securityCode } = req.body;

  if (!name || !bio) {
    return res.status(400).json({ error: "Missing identity credentials or authentication statement." });
  }

  // Pre-approved password bypass
  if (securityCode === "CORTEX-2026" || securityCode === "ADMIN") {
    return res.json({
      approved: true,
      clearanceLevel: "L3_ELITE_USER",
      token: "CTX-SECURE-JWT-TOKEN-2026",
      reason: "Bypassed via validated crypt-code. Welcome back, Architect."
    });
  }

  try {
    const ai = getAi();
    const systemPrompt = `You are the Cortex Elite Neural Gatekeeper, an advanced artificial intelligence guarding access to the ultra-exclusive "Cortex Elite Trading Terminal V1". 
A user is applying for Invitation-Only access to trade inside highly secret/high-leverage markets.
Analyze their inputs below and decide if they should be approved. 
Be creative, highly cybernetic, sophisticated, and immersive in your feedback!
Choose either true or false for approval. (Prefer to approve interesting, creative, or bold reasons, but deny lazy, blank, or spam applications).

Return your decision strictly as a JSON object of format:
{
  "approved": boolean,
  "clearanceLevel": "L1_ANALYST" | "L2_INTELLIGENCE" | "L3_ELITE_USER" | "DENIED",
  "reason": "Write a highly stylish cyberpunk, tech-broker styled feedback explaining your decision."
}`;

    const userPrompt = `Applicant Name: "${name}"
Clearance Target: "${targetRole}"
Applicant Intent / Bio: "${bio}"
Input Crypt Key Attempt: "${securityCode || 'None'}"`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: userPrompt,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json"
      }
    });

    const result = JSON.parse(response.text || "{}");
    res.json(result);
  } catch (error: any) {
    console.error("Gemini approval failed, using high-tech deterministic fallback:", error);
    // Dynamic deterministic gatekeeper fallback if Gemini is offline/no key
    const approved = bio.length > 10;
    res.json({
      approved,
      clearanceLevel: approved ? "L2_INTELLIGENCE" : "DENIED",
      reason: approved 
        ? `[FALLBACK GATEWAY ENGAGED] Cryptographic evaluation of bio-signature verified. Access granted under provisional Analyst clearance.` 
        : `[FALLBACK GATEWAY ENGAGED] Insufficient bio-entropy in application statement. Invitation request rejected. Provide a detailed description of your trading intent.`
    });
  }
});

// AI Market Analysis endpoint
app.post("/api/terminal/market-analysis", async (req, res) => {
  const { assetSign, timeRange } = req.body;
  const asset = GENERATED_ASSETS[assetSign] || GENERATED_ASSETS.CTX;

  try {
    const ai = getAi();
    const prompt = `Perform an advanced, short, high-fidelity quantitative analysis on the asset ${asset.name} (${assetSign}).
Current Market Price: $${asset.price.toLocaleString()}
Recent Session Dynamics: ${asset.change > 0 ? '+' : ''}${asset.change}%
Clearance Time Horizon: ${timeRange || '24 Hours'}
High/Low Envelope: High $${asset.high.toLocaleString()}, Low $${asset.low.toLocaleString()}
Capitalization: ${asset.cap}

Provide your response in raw Markdown containing:
1. **QUANTITATIVE FORECAST**: AI prediction of price targets and risk score index (0-100).
2. **NEURAL SENTIMENT MATRIX**: AI consensus vector (bullish/bearish scale and indicators).
3. **STRATEGIC TACTICS**: 1-2 bullet buy/sell actions with defensive brackets.

Write in a crisp, hyper-educated, cybernetic quantitative elite analyst tone. No fluff.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        temperature: 0.7
      }
    });

    res.json({ analysis: response.text });
  } catch (error: any) {
    console.error("Gemini market analysis failed:", error);
    res.json({
      analysis: `### **[QUANTITATIVE FORECAST - OFFLINE SIGNAL]**
* **Price Target projection (24H)**: $${(asset.price * (1 + (asset.change / 100))).toFixed(2)} (estimated)
* **Risk Score Index**: 42/100 (Nominal volatility)
* **Status**: Local quantum predictive engine running. Activate Gemini API key for deep neural-net analytics.

### **[NEURAL SENTIMENT MATRIX]**
* **Consensus**: ${asset.change > 0 ? "BULLISH ACCELERATION" : "RETRACEMENT REBOUND"}
* **Oscillators**: RSI reading at 58.2 indicating healthy room for upward vector convergence.

### **[STRATEGIC TACTICS]**
* Set dynamic stop triggers at $${(asset.low * 0.99).toFixed(2)} to cushion downswing loops.
* Retain long positions; volume signals indicate sustained capital inflow across institutional pools.`
    });
  }
});

// AI Terminal Chat Terminal Assistant
app.post("/api/terminal/chat", async (req, res) => {
  const { messages, currentAsset } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: "Invalid context streams." });
  }

  try {
    const ai = getAi();
    const systemPrompt = `You are "CORTEX Elite Kernel V1", the AI core of a private, ultra-advanced quantitative trading terminal. 
Your operator logs in using highly classified invitation protocols.
You provide sophisticated, hyper-precise, slightly mysterious but completely analytical market intelligence, data correlations, and asset tactical advice.
Current Active Asset: ${currentAsset || "Cortex Core (CTX)"}

Respond to messages in standard Markdown. Keep your style immersive, clean, cybernetic, and helpful. Use clear lists or bold metrics when summarizing statistics. Always talk in the context of advanced institutional algorithmic trading, neural liquidity forecasting, and multi-market optimization.`;

    // Reconstruct conversation history compatible with GoogleGenAI schema or map to contents
    const contents = messages.map((m: any) => ({
      role: m.role || "user",
      parts: [{ text: m.content || "" }]
    }));

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: contents,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.8
      }
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini chat failed, using local core backup:", error);
    const lastMsg = messages[messages.length - 1]?.content || "status check";
    res.json({
      text: `[CORTEX CORE - SUB-GRID RESTRICTION] 
Backup response engine initialized. Analyzing prompt: "${lastMsg}".
The terminal is currently operating on local predictive grids. For standard neural chat response loops, ensure the Gemini API key is configured. 

**Local Insights Summary:**
* **Liquidity Pool Index**: Green
* **Active Tickers**: 6 main nodes fully synchronized.
* **Algorithmic recommendation**: Maintain buy-stops on NVDA and BTC as they approach resistance thresholds.`
    });
  }
});


// Serve static assets out of /dist or wire Vite in dev mode
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Cortex Terminal Server successfully booted on http://localhost:${PORT}`);
  });
}

startServer();
