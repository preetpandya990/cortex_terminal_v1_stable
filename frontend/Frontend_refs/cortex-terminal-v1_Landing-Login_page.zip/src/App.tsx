import React, { useState, useEffect } from "react";
import { 
  Lock, 
  Unlock, 
  Cpu, 
  Wallet, 
  Activity, 
  TrendingUp, 
  User, 
  Mail, 
  ArrowUpRight, 
  ArrowDownRight,
  LogOut, 
  Eye, 
  EyeOff, 
  Award, 
  Terminal, 
  CheckCircle2, 
  Zap,
  Globe,
  BellRing,
  HelpCircle
} from "lucide-react";

import ParticleGlobe from "./components/ParticleGlobe";
import AIPredictions from "./components/AIPredictions";
import TerminalChat from "./components/TerminalChat";
import RequestAccessModal from "./components/RequestAccessModal";
import { Asset, TradeOrder } from "./types";

const INITIAL_ASSETS: Asset[] = [
  { symbol: "CTX", name: "Cortex AI Core", price: 341.25, change: 12.4, history: [310, 312, 318, 315, 324, 330, 341.25], high: 345.00, low: 308.50, volume: "1.2B CTX", cap: "$68.2B" },
  { symbol: "BTC", name: "Bitcoin Core", price: 98450.00, change: 2.1, history: [97100, 96800, 98200, 97900, 98100, 97500, 98450.00], high: 99100.00, low: 96400.00, volume: "24.5K BTC", cap: "$1.95T" },
  { symbol: "ETH", name: "Ethereum Core", price: 3420.50, change: -1.3, history: [3480, 3450, 3440, 3495, 3460, 3410, 3420.50], high: 3512.00, low: 3390.00, volume: "185.2K ETH", cap: "$412.4B" },
  { symbol: "TSLA", name: "Tesla Labs", price: 212.80, change: 4.8, history: [198, 201, 205, 202, 209, 210, 212.80], high: 215.10, low: 196.20, volume: "12.4M TSLA", cap: "$678.5B" },
  { symbol: "NVDA", name: "Nvidia Neural", price: 127.45, change: 8.2, history: [115, 118, 120, 119, 124, 125, 127.45], high: 129.00, low: 114.50, volume: "28.1M NVDA", cap: "$3.12T" },
  { symbol: "AAPL", name: "Apple Core", price: 178.60, change: -0.4, history: [179.5, 180.1, 178.9, 179.2, 177.5, 178.1, 178.60], high: 181.20, low: 176.80, volume: "8.4M AAPL", cap: "$2.78T" }
];

export default function App() {
  // Page routing
  const [currentPage, setCurrentPage] = useState<"login" | "terminal">("login");
  const [clearanceLevel, setClearanceLevel] = useState<string>("L1_ANALYST");

  // Authentication Fields (for exact design replication)
  const [userEmail, setUserEmail] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [loginError, setLoginError] = useState<string>("");

  // Access Portal popup
  const [isAccessModalOpen, setIsAccessModalOpen] = useState<boolean>(false);

  // High-fidelity active simulation datasets
  const [assets, setAssets] = useState<Asset[]>(INITIAL_ASSETS);
  const [selectedAssetSymbol, setSelectedAssetSymbol] = useState<string>("CTX");
  
  // Simulated Ledger State
  const [balance, setBalance] = useState<number>(100000); // Default $100,000 elite portfolio starting balance!
  const [positions, setPositions] = useState<Record<string, number>>({ CTX: 10, BTC: 0.25 });
  const [orders, setOrders] = useState<TradeOrder[]>([
    { id: "init-1", timestamp: "08:14:22", symbol: "CTX", type: "BUY", price: 310.00, amount: 10, total: 3100 },
    { id: "init-2", timestamp: "09:30:11", symbol: "BTC", type: "BUY", price: 97100.00, amount: 0.25, total: 24275 }
  ]);
  const [successMemo, setSuccessMemo] = useState<string>("");

  const activeAsset = assets.find(a => a.symbol === selectedAssetSymbol) || assets[0];

  // Dynamic Ticker simulation - drives real-time updates across quant desks!
  useEffect(() => {
    const interval = setInterval(() => {
      setAssets(current => 
        current.map(asset => {
          // Generous walk, average walk (-0.4% to +0.6%)
          const pct = 1 + (Math.random() * 0.01 - 0.004);
          const newPrice = asset.price * pct;
          const deltaPrice = newPrice - asset.price;
          const newHistory = [...asset.history.slice(1), newPrice];
          const newHigh = Math.max(asset.high, newPrice);
          const newLow = Math.min(asset.low, newPrice);
          // Recalculate 24H changes slightly
          const totalChange = parseFloat((asset.change + (pct - 1) * 100).toFixed(2));

          return {
            ...asset,
            price: parseFloat(newPrice.toFixed(2)),
            change: totalChange,
            history: newHistory,
            high: parseFloat(newHigh.toFixed(2)),
            low: parseFloat(newLow.toFixed(2))
          };
        })
      );
    }, 4500);

    return () => clearInterval(interval);
  }, []);

  // Secure Sign-in process matching general guidelines
  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userEmail || !password) {
      setLoginError("Credentials cannot be null. Re-input stream.");
      return;
    }

    // Accept typical credentials or known bypass code
    if (userEmail.length > 3 && password.length > 4) {
      setClearanceLevel("L2_INTELLIGENCE");
      setCurrentPage("terminal");
      setLoginError("");
    } else {
      setLoginError("Evaluation failure: Account unauthorized. Create access token first.");
    }
  };

  // Secure Order Processor
  const handleExchange = (type: "BUY" | "SELL", amount: number) => {
    const cost = activeAsset.price * amount;
    const timeStr = new Date().toLocaleTimeString(undefined, { hour12: false });

    if (type === "BUY") {
      if (balance < cost) {
        setSuccessMemo("ALERT: Insufficient collateral balance in quant pool.");
        setTimeout(() => setSuccessMemo(""), 4000);
        return;
      }

      setBalance(b => b - cost);
      setPositions(pos => ({
        ...pos,
        [selectedAssetSymbol]: (pos[selectedAssetSymbol] || 0) + amount
      }));

      const newOrder: TradeOrder = {
        id: Math.random().toString(),
        timestamp: timeStr,
        symbol: selectedAssetSymbol,
        type,
        price: activeAsset.price,
        amount,
        total: cost
      };

      setOrders(o => [newOrder, ...o]);
      setSuccessMemo(`SUCCESS: Acquired ${amount} ${selectedAssetSymbol} @ $${activeAsset.price.toLocaleString()}`);
      setTimeout(() => setSuccessMemo(""), 4000);
    } else {
      const currentHold = positions[selectedAssetSymbol] || 0;
      if (currentHold < amount) {
        setSuccessMemo(`ALERT: Insufficient position allocation to execute Sell Order.`);
        setTimeout(() => setSuccessMemo(""), 4000);
        return;
      }

      setBalance(b => b + cost);
      setPositions(pos => ({
        ...pos,
        [selectedAssetSymbol]: Math.max(0, currentHold - amount)
      }));

      const newOrder: TradeOrder = {
        id: Math.random().toString(),
        timestamp: timeStr,
        symbol: selectedAssetSymbol,
        type,
        price: activeAsset.price,
        amount,
        total: cost
      };

      setOrders(o => [newOrder, ...o]);
      setSuccessMemo(`SUCCESS: Liquidated ${amount} ${selectedAssetSymbol} @ $${activeAsset.price.toLocaleString()}`);
      setTimeout(() => setSuccessMemo(""), 4000);
    }
  };

  // Logo render matching screenshot top left
  const CortexLogo = () => (
    <div className="flex items-center gap-2">
      <div className="relative w-8 h-8 flex items-center justify-center border border-cyan-400 bg-cyan-950/20 rounded-md">
        <div className="absolute inset-0.5 border border-dashed border-cyan-400/40" />
        <span className="font-display font-black text-xs text-cyan-400">CX</span>
      </div>
      <div className="flex flex-col select-none text-left">
        <span className="font-display font-medium leading-none tracking-[0.2em] text-sm text-white">CORTEX</span>
        <span className="font-mono text-[8px] text-cyan-400/80 mt-0.5 tracking-wider">TERMINAL · V1</span>
      </div>
    </div>
  );

  return (
    <div className="relative min-h-screen bg-[#030712] overflow-x-hidden flex flex-col justify-between selection:bg-cyan-500 selection:text-slate-950">
      
      {/* Dynamic scanlines */}
      <div className="absolute inset-0 z-0 h-full w-full bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-950 via-[#04081c] to-slate-950 pointer-events-none" />
      <div className="absolute inset-0 z-0 cyber-grid opacity-15 pointer-events-none" />
      <div className="terminal-scanline" />

      {/* LOGIN PAGE */}
      {currentPage === "login" && (
        <>
          <ParticleGlobe />
          <div className="relative z-10 flex-1 flex flex-col justify-between w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            {/* Top navigation branding rail */}
            <header className="flex items-center justify-between w-full border-b border-cyan-500/10 pb-4">
              <CortexLogo />
              <div className="font-mono text-[10px] text-cyan-400/60 hidden sm:flex items-center gap-2">
                <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                SECURE ENUMERATION PORT 443 | CO_GRID CONNECTED
              </div>
            </header>

            {/* Core Screen Layout (Left Grid: Visual Globe, Right Grid: Login Box) */}
            <main className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center my-6 lg:my-10 flex-1">
              
              {/* Left Box (Globe + Core Titles) */}
              <section className="lg:col-span-7 flex flex-col justify-center items-start text-left min-h-[350px] lg:min-h-[500px]">
                
                {/* Spacer container to let the full viewport cosmic globe align dynamically behind the Left section */}
                <div className="w-full max-w-lg h-[240px] sm:h-[320px] mx-auto md:mx-0 relative mb-4 animate-pulse-slow" />

                {/* Cortex Elite Titles */}
              <div className="flex flex-col gap-1 sm:gap-2">
                <h1 className="font-display font-bold text-4xl sm:text-5xl lg:text-6xl tracking-tight leading-tight uppercase font-black bg-gradient-to-br from-white via-cyan-100 to-blue-300 bg-clip-text text-transparent">
                  Cortex Elite <br />
                  <span className="text-cyan-400 glow-heavy-cyan">Terminal V1</span>
                </h1>
                <p className="font-display font-medium text-xs sm:text-sm lg:text-base text-cyan-400/90 tracking-[0.25em] uppercase leading-relaxed mt-2 max-w-xl">
                  AI-Native Trading Intelligence <br className="sm:hidden" /> For Exclusive Markets
                </p>
              </div>
            </section>

            {/* Right Box (Glassmorphic Sign In Card) */}
            <section className="lg:col-span-5 flex justify-center lg:justify-end w-full">
              <div 
                id="sign-in-panel" 
                className="w-full max-w-md bg-gradient-to-b from-[#0b142d]/80 to-[#04081c]/90 border border-cyan-500/25 rounded-2xl p-6 sm:p-8 flex flex-col gap-5 shadow-2xl backdrop-blur-xl relative"
              >
                {/* Visual anchor corners */}
                <span className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-cyan-400 rounded-tl" />
                <span className="absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 border-cyan-400 rounded-tr" />
                <span className="absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-cyan-400 rounded-bl" />
                <span className="absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-cyan-400 rounded-br" />

                {/* Card Title */}
                <div className="text-center">
                  <h2 id="login-title" className="font-display font-medium text-3xl text-cyan-400 tracking-wide select-none glow-heavy-cyan">
                    Sign In
                  </h2>
                  <p className="font-mono text-[10px] text-gray-500 tracking-wider uppercase mt-1">
                    Invitation-Only Access
                  </p>
                </div>

                {/* Form Elements */}
                <form id="login-form" onSubmit={handleSignIn} className="flex flex-col gap-4">
                  
                  {/* Email / Username field */}
                  <div className="flex flex-col gap-1 text-left">
                    <label id="username-lbl" htmlFor="signin-username" className="font-mono text-[11px] text-gray-400 uppercase tracking-wider">
                      Username or email
                    </label>
                    <div className="relative">
                      <input
                        id="signin-username"
                        type="text"
                        required
                        value={userEmail}
                        onChange={(e) => setUserEmail(e.target.value)}
                        placeholder="operator@cortex.ai"
                        className="w-full bg-[#060b1e]/90 text-cyan-300 font-mono text-sm px-4 py-3 border border-cyan-500/20 focus:border-cyan-400 hover:border-cyan-500/35 rounded-lg focus:outline-none placeholder-cyan-500/30 transition-all shadow-inner"
                      />
                      <User className="absolute right-3.5 top-3.5 w-4 h-4 text-cyan-500/35" />
                    </div>
                  </div>

                  {/* Password field */}
                  <div className="flex flex-col gap-1 text-left">
                    <label id="password-lbl" htmlFor="signin-password" className="font-mono text-[11px] text-gray-400 uppercase tracking-wider">
                      Password
                    </label>
                    <div className="relative">
                      <input
                        id="signin-password"
                        type={showPassword ? "text" : "password"}
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••••••"
                        className="w-full bg-[#060b1e]/90 text-cyan-300 font-mono text-sm px-4 py-3 border border-cyan-500/20 focus:border-cyan-400 hover:border-cyan-500/35 rounded-lg focus:outline-none placeholder-cyan-500/30 transition-all shadow-inner pr-12"
                      />
                      <button
                        id="pwd-reveal-btn"
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3.5 top-3.5 p-0.5 text-cyan-500/35 hover:text-cyan-400 cursor-pointer"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Errors block */}
                  {loginError && (
                    <div className="text-[11px] font-mono text-rose-400 bg-rose-950/20 border border-rose-500/20 p-2 rounded text-left">
                      {loginError}
                    </div>
                  )}

                  {/* Main Sign in Click trigger */}
                  <button
                    id="submit-login-btn"
                    type="submit"
                    className="w-full mt-2 py-3 bg-gradient-to-r from-cyan-500 via-cyan-400 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-slate-950 font-display font-medium rounded-lg shadow-lg shadow-cyan-500/20 hover:shadow-cyan-400/40 hover:scale-[1.01] active:translate-y-0.5 transition-all text-sm tracking-wide cursor-pointer flex items-center justify-center gap-1.5 font-bold"
                  >
                    Sign In
                  </button>
                </form>

                {/* Sub links action lists */}
                <div className="flex flex-col items-center gap-2 mt-2 pt-2 border-t border-cyan-500/10">
                  <button
                    id="forgot-pwd-btn"
                    onClick={() => {
                      alert("SECURITY INSTRUCTIONS:\nCorporate-issued crypt-tokens can only be recovered via verified quantum bio-scans matching original L3 recruitment pools. Request Access or contact an Admin below.");
                    }}
                    className="font-sans text-[11px] text-gray-500 hover:text-cyan-400 cursor-pointer transition-all"
                  >
                    Forgot password?
                  </button>

                  <button
                    id="request-access-btn"
                    onClick={() => setIsAccessModalOpen(true)}
                    className="font-sans text-xs text-cyan-400 hover:text-white font-medium tracking-wide flex items-center gap-1 mt-1 cursor-pointer hover:underline"
                  >
                    Request Access (Admin Only)
                  </button>
                </div>

                {/* Bottom indicators inside card boundary */}
                <div className="flex items-center justify-between border-t border-cyan-500/10 pt-4 mt-1">
                  <div className="flex items-center gap-1.5 select-none text-[11px]">
                    <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse border border-emerald-300" />
                    <span className="font-sans text-emerald-400 font-medium">All systems operational</span>
                  </div>
                  <span className="font-mono text-[10px] text-gray-600 select-none">
                    © 2026 Cortex AI
                  </span>
                </div>

              </div>
            </section>

          </main>

          {/* Base bottom disclaimer */}
          <footer className="border-t border-cyan-500/5 pt-4 font-mono text-[9px] text-gray-600 flex flex-wrap justify-between gap-2">
            <div>CLEARANCE CODE DEFINITIONS: SECURE INSTITUTIONAL CHANNELS ONLY</div>
            <div>VER: 1.0.24-AISTUDIO</div>
          </footer>
        </div>
        </>
      )}

      {/* COCKPIT EXECUTIVE TRADING TERMANAL */}
      {currentPage === "terminal" && (
        <div className="relative z-10 flex-1 flex flex-col w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          
          {/* Dashboard Header Rail */}
          <header className="flex flex-wrap items-center justify-between gap-4 border-b border-cyan-500/10 pb-4 mb-5">
            <div className="flex items-center gap-4">
              <CortexLogo />
              <div className="h-5 w-px bg-cyan-500/20 hidden sm:block" />
              <div className="hidden sm:flex items-center gap-1.5 font-mono text-[10px] bg-cyan-950/40 text-cyan-300 border border-cyan-500/10 px-2.5 py-1 rounded-full">
                <Award className="w-3.5 h-3.5 text-yellow-400" />
                CLEARANCE LEVEL: <span className="font-bold">{clearanceLevel}</span>
              </div>
            </div>

            {/* Wallet metrics & logout */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 bg-[#0b1329]/90 border border-cyan-500/10 px-3.5 py-1.5 rounded-lg font-mono text-xs">
                <Wallet className="w-4 h-4 text-cyan-400" />
                <span className="text-gray-400">LIQUID POOL:</span> 
                <span className="text-cyan-400 font-bold">
                  ${balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>

              <button
                id="terminate-connection-btn"
                onClick={() => {
                  setCurrentPage("login");
                }}
                className="p-1.5 px-3 rounded-lg bg-rose-950/20 hover:bg-rose-950/45 border border-rose-500/10 hover:border-rose-500/35 text-xs text-rose-400 transition-all cursor-pointer flex items-center gap-1.5 font-medium"
              >
                <LogOut className="w-3.5 h-3.5" /> TERMINATE
              </button>
            </div>
          </header>

          {/* Success action notification banner */}
          {successMemo && (
            <div className="mb-4 bg-cyan-950/40 border border-cyan-400/30 text-cyan-300 p-3 rounded-lg font-mono text-xs flex items-center justify-between gap-3 animate-slideDown shadow-lg">
              <div className="flex items-center gap-2">
                <BellRing className="w-4 h-4 text-cyan-400 animate-bounce" />
                <span>{successMemo}</span>
              </div>
              <span className="text-[10px] text-cyan-500 opacity-60">ACTIVE LEDGER UPDATE</span>
            </div>
          )}

          {/* Grid Layout of the trading interface */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 flex-1 items-start">
            
            {/* LEFT COLUMN: Asset Universe list (col-span-3) */}
            <section className="lg:col-span-3 bg-[#0b1329]/60 backdrop-blur-xl border border-cyan-500/10 rounded-xl p-4 flex flex-col gap-4 self-stretch">
              <div className="border-b border-cyan-500/10 pb-2 mb-1">
                <h3 className="font-display font-bold text-xs text-cyan-400 tracking-wider uppercase flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5" /> SYSTEMIC ASSET INDEX
                </h3>
              </div>

              <div className="flex flex-col gap-2 overflow-y-auto max-h-[450px] pr-1">
                {assets.map((asset) => {
                  const isSelect = asset.symbol === selectedAssetSymbol;
                  const isPos = asset.change >= 0;
                  return (
                    <button
                      id={`asset-select-${asset.symbol}`}
                      key={asset.symbol}
                      onClick={() => setSelectedAssetSymbol(asset.symbol)}
                      className={`w-full px-3.5 py-3 rounded-lg text-left border transition-all cursor-pointer flex justify-between items-center ${
                        isSelect 
                          ? "bg-cyan-950/40 border-cyan-400/40 shadow shadow-cyan-500/10" 
                          : "bg-slate-900/40 border-cyan-500/5 hover:border-cyan-500/20"
                      }`}
                    >
                      <div className="flex flex-col gap-0.5">
                        <span className="font-mono text-sm font-bold text-white leading-none">{asset.symbol}</span>
                        <span className="font-sans text-[10px] text-gray-400 mt-0.5">{asset.name}</span>
                      </div>
                      <div className="text-right">
                        <span className="font-mono text-sm font-bold block text-cyan-400 leading-none">
                          ${asset.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </span>
                        <span className={`font-mono text-[10px] font-semibold mt-0.5 inline-block ${isPos ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {isPos ? "+" : ""}{asset.change}%
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Account allocations table */}
              <div className="bg-slate-950/50 p-3 rounded-lg border border-cyan-500/5 text-left mt-2">
                <span className="font-mono text-[10px] text-gray-500 uppercase font-semibold">ALLOCATIONS COMPOSITION</span>
                
                <div className="flex flex-col gap-2 mt-2">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-gray-400">LIQUID USD</span>
                    <span className="text-cyan-400 font-bold">${balance.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                  </div>
                  {Object.entries(positions).map(([sym, qty]) => {
                    const price = assets.find(a => a.symbol === sym)?.price || 0;
                    const numQty = qty as number;
                    const value = numQty * price;
                    if (numQty <= 0) return null;
                    return (
                      <div key={sym} className="flex justify-between text-xs font-mono">
                        <span className="text-gray-300">{numQty} {sym}</span>
                        <span className="text-white">${value.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </section>

            {/* MIDDLE COLUMN: Quant predicting workspace (col-span-5) */}
            <section className="lg:col-span-5 self-stretch">
              <AIPredictions 
                currentAsset={activeAsset} 
                onTrade={handleExchange}
                balance={balance}
              />
            </section>

            {/* RIGHT COLUMN: Chat console & historical orders (col-span-4) */}
            <section className="lg:col-span-4 flex flex-col gap-5 self-stretch">
              
              {/* Quant Intelligence AI chat widget */}
              <TerminalChat currentAsset={activeAsset} />

              {/* Transactions Ledger Panel */}
              <div className="bg-[#0b1329]/60 backdrop-blur-xl border border-cyan-500/10 rounded-xl p-4 flex flex-col h-[200px] text-left">
                <div className="border-b border-cyan-500/10 pb-2 mb-2 flex justify-between items-center">
                  <h3 className="font-display font-semibold text-xs text-cyan-400 tracking-wider">
                    TRANSACTIONS HISTORIAN
                  </h3>
                  <span className="font-mono text-[9px] text-gray-500">LIVE COGNITION ORDERBOOK</span>
                </div>

                <div className="flex-1 overflow-y-auto pr-1 flex flex-col gap-1.5">
                  {orders.length === 0 ? (
                    <div className="text-center font-mono text-[10px] text-gray-500 py-6">
                      NO ACTIVE TRANSACTION PHASES LOGGED.
                    </div>
                  ) : (
                    orders.map((ord) => (
                      <div key={ord.id} className="flex justify-between items-center bg-slate-950/40 p-2 rounded border border-cyan-500/5 text-xs font-mono">
                        <div className="flex items-center gap-2">
                          <span className={`px-1 py-0.5 rounded text-[9px] font-bold ${ord.type === "BUY" ? 'bg-emerald-950/80 text-emerald-400' : 'bg-rose-950/80 text-rose-400'}`}>
                            {ord.type}
                          </span>
                          <span className="font-bold text-white">{ord.amount} {ord.symbol}</span>
                          <span className="text-gray-500 text-[10px]">@{ord.price.toLocaleString()}</span>
                        </div>
                        <div className="text-right flex flex-col items-end">
                          <span className="text-cyan-400 font-bold">${ord.total.toLocaleString(undefined, { minimumFractionDigits: 1 })}</span>
                          <span className="text-[8px] text-gray-500">{ord.timestamp}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

            </section>

          </div>
        </div>
      )}

      {/* ACCESS REQUEST MODAL POPUP */}
      {isAccessModalOpen && (
        <RequestAccessModal 
          onClose={() => setIsAccessModalOpen(false)} 
          onGrantAccess={(level) => {
            setClearanceLevel(level);
            // Grant access automatically simulates demo logging-in too!
            setUserEmail("elite.applicant@cortex.ai");
            setPassword("PROVISIONED-BY-AI");
            setCurrentPage("terminal");
          }}
        />
      )}

    </div>
  );
}
