import React, { useState, useRef, useEffect } from "react";
import { Send, Terminal, Cpu, Trash2, ShieldAlert } from "lucide-react";
import { Message, Asset } from "../types";

interface TerminalChatProps {
  currentAsset: Asset;
}

export default function TerminalChat({ currentAsset }: TerminalChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "init",
      role: "model",
      content: "Operator connected. CORTEX Elite Kernel V1 active. Ask me anything regarding deep-market simulations, volume liquidity indices, or quantitative strategies.",
      timestamp: new Date()
    }
  ]);
  const [inputVal, setInputVal] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const handleSend = async (customPrompt?: string) => {
    const promptToSend = customPrompt || inputVal;
    if (!promptToSend.trim() || loading) return;

    if (!customPrompt) setInputVal("");

    const userMsg: Message = {
      id: Math.random().toString(),
      role: "user",
      content: promptToSend,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setLoading(true);

    try {
      // Map message history into server API format
      const response = await fetch("/api/terminal/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, userMsg].map(m => ({ role: m.role, content: m.content })),
          currentAsset: `${currentAsset.name} (${currentAsset.symbol})`
        })
      });

      const data = await response.json();
      
      const modelMsg: Message = {
        id: Math.random().toString(),
        role: "model",
        content: data.text || "Synchronous response timeout. Re-evaluate sub-grids.",
        timestamp: new Date()
      };

      setMessages(prev => [...prev, modelMsg]);
    } catch {
      const errorMsg: Message = {
        id: Math.random().toString(),
        role: "model",
        content: "[CORE LOG ERROR] Failed to synchronize intelligence packet with Express node. Activate your Gemini API key in Secrets to restore natural conversations.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const clearSession = () => {
    setMessages([
      {
        id: Math.random().toString(),
        role: "model",
        content: "Memory buffers flushed. Neural session restarted. State ready.",
        timestamp: new Date()
      }
    ]);
  };

  const SHORTCUTS = [
    { label: "Analyze global market sentiment", prompt: "Perform a detailed analysis of current global cryptocurrency and stock market trends. What is the overall macro consensus?" },
    { label: "Cortex Network arbitrage anomaly", prompt: "Explain the systemic arbitrage metrics for the Cortex AI ecosystem. Are there active volume imbalances?" },
    { label: "Assess immediate systemic risk vectors", prompt: "What are the immediate systemic risk vectors to watch over the next 48 hours for liquid capital allocations?" }
  ];

  return (
    <div id="terminal-chat-widget" className="bg-[#0b1329]/60 backdrop-blur-xl border border-cyan-500/10 rounded-xl p-5 flex flex-col h-[520px]">
      {/* Title block */}
      <div className="flex items-center justify-between border-b border-cyan-500/10 pb-3 mb-4">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-cyan-400" />
          <span className="font-display font-semibold text-sm text-white">QUANT INTELLIGENCE CHAT</span>
        </div>
        <button
          id="clear-chat-btn"
          onClick={clearSession}
          className="p-1 px-2.5 rounded bg-cyan-950/20 hover:bg-rose-950/30 border border-cyan-500/10 hover:border-rose-500/30 text-xs text-cyan-400 hover:text-rose-400 flex items-center gap-1.5 transition-all cursor-pointer"
          title="Clear Session"
        >
          <Trash2 className="w-3 h-3" /> FLUSH BUFFERS
        </button>
      </div>

      {/* Messages stream viewport */}
      <div className="flex-1 overflow-y-auto pr-1 flex flex-col gap-4 mb-4">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col gap-1 max-w-[85%] ${msg.role === "user" ? "self-end items-end" : "self-start items-start"}`}
          >
            {/* Header identity */}
            <span className="font-mono text-[9px] text-gray-500 flex items-center gap-1">
              {msg.role === "user" ? "OPERATOR" : <><Cpu className="w-3 h-3 text-cyan-400" /> CORTEX CLIENT</>}
              <span>•</span>
              {msg.timestamp.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
            </span>
            
            {/* Message payload */}
            <div
              className={`rounded-lg p-3 text-sm font-sans leading-relaxed border ${
                msg.role === "user"
                  ? "bg-cyan-950/40 border-cyan-500/30 text-cyan-100"
                  : msg.content.includes("ERROR") 
                    ? "bg-rose-950/20 border-rose-500/30 text-rose-300"
                    : "bg-slate-900/60 border-cyan-500/5 text-gray-200"
              }`}
            >
              <div className="whitespace-pre-line break-words">
                {msg.content}
              </div>
            </div>
          </div>
        ))}
        {loading && (
          <div className="self-start flex flex-col gap-1 items-start">
            <span className="font-mono text-[9px] text-gray-500 flex items-center gap-1 animate-pulse">
              <Cpu className="w-3 h-3 text-cyan-400 animate-spin" /> THINKING NODE ACTIVE...
            </span>
            <div className="bg-slate-900/40 border border-cyan-500/5 rounded-lg p-3 py-4 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce" />
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce delay-100" />
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce delay-200" />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Suggestion Shortcuts chips */}
      {messages.length === 1 && !loading && (
        <div className="flex flex-col gap-1.5 mb-3 z-10">
          <span className="font-mono text-[9px] text-gray-500 flex items-center gap-1">
            <ShieldAlert className="w-3 h-3 text-cyan-400" /> SELECT FLOATING INTENT CHIPS
          </span>
          <div className="flex flex-wrap gap-1.5">
            {SHORTCUTS.map((sc, scIdx) => (
              <button
                id={`sc-btn-${scIdx}`}
                key={scIdx}
                onClick={() => handleSend(sc.prompt)}
                className="text-[10px] bg-slate-950/60 hover:bg-cyan-950/40 border border-cyan-500/10 hover:border-cyan-500/30 text-cyan-300/90 rounded px-2.5 py-1 text-left transition-all cursor-pointer"
              >
                {sc.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Inputs bar */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSend();
        }}
        className="flex items-center gap-2 mt-auto"
      >
        <input
          id="chat-input-box"
          type="text"
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value)}
          placeholder={`Inquire Cortex core about ${currentAsset.symbol} positions...`}
          disabled={loading}
          className="flex-1 bg-slate-950 border border-cyan-500/20 focus:border-cyan-400 rounded-lg px-4 py-2.5 font-mono text-sm text-cyan-300 focus:outline-none placeholder-cyan-500/40 disabled:opacity-50"
        />
        <button
          id="chat-submit-btn"
          type="submit"
          disabled={loading || !inputVal.trim()}
          className="p-2.5 bg-cyan-500 text-slate-950 rounded-lg font-bold border border-cyan-300 hover:bg-cyan-400 transition-all cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
}
