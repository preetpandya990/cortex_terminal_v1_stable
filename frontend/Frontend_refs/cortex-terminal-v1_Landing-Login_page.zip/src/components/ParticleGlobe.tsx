import React, { useEffect, useRef } from "react";

interface Point3D {
  x: number;
  y: number;
  z: number;
  baseX: number;
  baseY: number;
  baseZ: number;
  color: string;
  size: number;
}

interface BackgroundStar {
  x: number;
  y: number;
  baseX: number;
  baseY: number;
  size: number;
  color: string;
  speedX: number;
  speedY: number;
}

export default function ParticleGlobe() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const mouseRef = useRef<{ x: number; y: number; active: boolean }>({ x: 0, y: 0, active: false });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    // Handle Resize
    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener("resize", handleResize);

    // Capture cursor coordinates anywhere in the WINDOW, not just bounded inside a small box!
    const onMouseMove = (e: MouseEvent) => {
      mouseRef.current = {
        x: e.clientX,
        y: e.clientY,
        active: true,
      };
    };

    const onMouseLeave = () => {
      mouseRef.current.active = false;
    };

    const onTouchMove = (e: TouchEvent) => {
      if (e.touches && e.touches.length > 0) {
        mouseRef.current = {
          x: e.touches[0].clientX,
          y: e.touches[0].clientY,
          active: true,
        };
      }
    };

    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseleave", onMouseLeave);
    window.addEventListener("touchmove", onTouchMove, { passive: true });

    // Center locator handles responsive layout centering
    const getCenter = () => {
      // Scale globe on desktop to floating left side, on mobile we center it
      const centerX = width > 1024 ? width * 0.35 : width * 0.5;
      const centerY = height * 0.44;
      const radius = Math.min(width, height) * (width > 640 ? 0.36 : 0.45);
      return { centerX, centerY, radius };
    };

    // Generate majestic sphere node coordinates (Earth structure)
    const globePoints: Point3D[] = [];
    const globeCount = 480; 
    
    for (let i = 0; i < globeCount; i++) {
      // Golden ratio sphere distribution
      const phi = Math.acos(-1 + (2 * i) / globeCount);
      const theta = Math.sqrt(globeCount * Math.PI) * phi;
      
      const r = 1.0; 
      const x = r * Math.sin(phi) * Math.cos(theta);
      const y = r * Math.cos(phi);
      const z = r * Math.sin(phi) * Math.sin(theta);

      const rand = Math.random();
      const color = rand > 0.94 
        ? "rgba(34, 211, 238, 0.95)" // Cyan star star
        : rand > 0.65 
          ? "rgba(59, 130, 246, 0.70)" // Luminous blue star
          : "rgba(6, 182, 212, 0.30)"; // Dim network bounds

      const size = rand > 0.94 ? 3.0 : rand > 0.65 ? 1.7 : 1.0;

      globePoints.push({ x, y, z, baseX: x, baseY: y, baseZ: z, color, size });
    }

    // Generate surrounding space particles and stardust nodes
    const bgStars: BackgroundStar[] = [];
    const bgStarCount = 200; 

    for (let i = 0; i < bgStarCount; i++) {
      const x = Math.random() * width;
      const y = Math.random() * height;
      const size = Math.random() * 2.0 + 0.6;
      const opacity = Math.random() * 0.45 + 0.15;
      
      const color = Math.random() > 0.75 
        ? `rgba(34, 211, 238, ${opacity})` 
        : Math.random() > 0.45 
          ? `rgba(59, 130, 246, ${opacity})` 
          : `rgba(229, 231, 235, ${opacity * 0.7})`;

      bgStars.push({
        x,
        y,
        baseX: x,
        baseY: y,
        size,
        color,
        speedX: (Math.random() - 0.5) * 0.16,
        speedY: (Math.random() - 0.5) * 0.16
      });
    }

    let angleX = 0.0006; 
    let angleY = 0.0022; 
    let currentYRotation = 0;
    let currentXRotation = 0;

    // Render loop
    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // A. Starry ambient glow around mouse pointer
      if (mouseRef.current.active) {
        const mouseGrad = ctx.createRadialGradient(
          mouseRef.current.x, mouseRef.current.y, 0,
          mouseRef.current.x, mouseRef.current.y, 200
        );
        mouseGrad.addColorStop(0, "rgba(6, 182, 212, 0.08)");
        mouseGrad.addColorStop(0.5, "rgba(59, 130, 246, 0.02)");
        mouseGrad.addColorStop(1, "transparent");
        ctx.fillStyle = mouseGrad;
        ctx.beginPath();
        ctx.arc(mouseRef.current.x, mouseRef.current.y, 200, 0, Math.PI * 2);
        ctx.fill();
      }

      // B. Animate drifting starry space dust responding to cursor
      for (let i = 0; i < bgStars.length; i++) {
        const star = bgStars[i];

        // Slowly drift starry points in space
        star.baseX += star.speedX;
        star.baseY += star.speedY;

        // Space looping boundaries
        if (star.baseX < 0) star.baseX = width;
        if (star.baseX > width) star.baseX = 0;
        if (star.baseY < 0) star.baseY = height;
        if (star.baseY > height) star.baseY = 0;

        let targetX = star.baseX;
        let targetY = star.baseY;

        // Magnetized gravity offsets
        if (mouseRef.current.active) {
          const dx = mouseRef.current.x - star.baseX;
          const dy = mouseRef.current.y - star.baseY;
          const distance = Math.hypot(dx, dy);
          const influence = 250; // Capture radius of mouse gravity

          if (distance < influence) {
            const pullFactor = (influence - distance) / influence;
            // Repel / push slightly away to create clear interactive ripple
            targetX -= (dx / distance) * pullFactor * 32;
            targetY -= (dy / distance) * pullFactor * 32;
          }
        }

        // Apply smooth ease spring physics
        star.x += (targetX - star.x) * 0.08;
        star.y += (targetY - star.y) * 0.08;

        // Render space point
        ctx.fillStyle = star.color;
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
        ctx.fill();

        // Dynamically create micro constellations near active mouse pointer!
        if (mouseRef.current.active) {
          const relativeCursorDist = Math.hypot(mouseRef.current.x - star.x, mouseRef.current.y - star.y);
          if (relativeCursorDist < 140) {
            // Check adjacent stars to bridge neural nodes
            for (let j = i + 1; j < bgStars.length; j++) {
              const otherStar = bgStars[j];
              const starToStarDist = Math.hypot(star.x - otherStar.x, star.y - otherStar.y);
              if (starToStarDist < 45) {
                const alpha = (1 - (relativeCursorDist / 140)) * (1 - (starToStarDist / 45)) * 0.15;
                ctx.strokeStyle = `rgba(34, 211, 238, ${alpha})`;
                ctx.lineWidth = 0.55;
                ctx.beginPath();
                ctx.moveTo(star.x, star.y);
                ctx.lineTo(otherStar.x, otherStar.y);
                ctx.stroke();
              }
            }
          }
        }
      }

      // C. Render spinning 3D holographic quantum globe on Left panel
      const { centerX, centerY, radius } = getCenter();

      currentYRotation += angleY;
      currentXRotation += angleX;

      // Mouse interactive pitch/tilt coordinates
      let extraXRotation = 0;
      let extraYRotation = 0;
      if (mouseRef.current.active) {
        const dx = (mouseRef.current.x - centerX) / width;
        const dy = (mouseRef.current.y - centerY) / height;
        extraYRotation = dx * 0.82; 
        extraXRotation = -dy * 0.82;
      }

      // Atmospheric spatial gradient layout
      const atmosphereGrad = ctx.createRadialGradient(
        centerX, centerY, radius * 0.05, 
        centerX, centerY, radius * 1.55
      );
      atmosphereGrad.addColorStop(0, "rgba(8, 47, 73, 0.32)");
      atmosphereGrad.addColorStop(0.5, "rgba(6, 182, 212, 0.05)");
      atmosphereGrad.addColorStop(1, "transparent");
      ctx.fillStyle = atmosphereGrad;
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius * 1.55, 0, Math.PI * 2);
      ctx.fill();

      // Latitude and Longitude projected circular orbital bounds
      const rings = 5;
      ctx.strokeStyle = "rgba(6, 182, 212, 0.09)";
      ctx.lineWidth = 1;
      for (let r = 0; r < rings; r++) {
        ctx.beginPath();
        const tilt = (r * Math.PI) / rings;
        for (let a = 0; a <= Math.PI * 2 + 0.12; a += 0.1) {
          const rx = radius * Math.cos(a);
          const ry = 0;
          const rz = radius * Math.sin(a);

          // Rotate around Z axis to map tilt direction offset
          const xTilted = rx * Math.cos(tilt) - ry * Math.sin(tilt);
          const yTilted = rx * Math.sin(tilt) + ry * Math.cos(tilt);

          // Apply rotation steps (automatic slow drift + mouse tilting)
          const yRot1 = yTilted * Math.cos(currentXRotation + extraXRotation) - rz * Math.sin(currentXRotation + extraXRotation);
          const zRot1 = yTilted * Math.sin(currentXRotation + extraXRotation) + rz * Math.cos(currentXRotation + extraXRotation);

          const xRot2 = xTilted * Math.cos(currentYRotation + extraYRotation) + zRot1 * Math.sin(currentYRotation + extraYRotation);
          const zRot2 = -xTilted * Math.sin(currentYRotation + extraYRotation) + zRot1 * Math.cos(currentYRotation + extraYRotation);

          // Perspective vector scaling
          const fov = 1000;
          const scale = fov / (fov + zRot2);
          const projX = centerX + xRot2 * scale;
          const projY = centerY + yRot1 * scale;

          if (a === 0) {
            ctx.moveTo(projX, projY);
          } else {
            ctx.lineTo(projX, projY);
          }
        }
        ctx.stroke();
      }

      // Outer satellite circuit ring
      ctx.strokeStyle = "rgba(34, 211, 238, 0.15)";
      ctx.lineWidth = 1.5;
      ctx.setLineDash([5, 12]);
      ctx.beginPath();
      const outerRad = radius * 1.15;
      const ringRot = currentYRotation * -1.1;
      
      for (let a = 0; a <= Math.PI * 2 + 0.1; a += 0.05) {
        const rx = outerRad * Math.cos(a + ringRot);
        const rz = outerRad * Math.sin(a + ringRot);
        const ry = rx * 0.22; // subtle slope

        const fov = 1000;
        const scale = fov / (fov + rz);
        const projX = centerX + rx * scale;
        const projY = centerY + ry * scale;

        if (a === 0) ctx.moveTo(projX, projY);
        else ctx.lineTo(projX, projY);
      }
      ctx.stroke();
      ctx.setLineDash([]); // Reset line dash

      interface ProjectedNode {
        projX: number;
        projY: number;
        scale: number;
        z: number;
        color: string;
        size: number;
      }

      const projectedGlobe: ProjectedNode[] = [];

      for (let i = 0; i < globePoints.length; i++) {
        const p = globePoints[i];

        // Apply radius dimensions to normalized sphere factors
        const rx = p.baseX * radius;
        const ry = p.baseY * radius;
        const rz = p.baseZ * radius;

        // Apply continuous dynamic rotation on X boundary
        const rotXVal = currentXRotation + extraXRotation;
        const y1 = ry * Math.cos(rotXVal) - rz * Math.sin(rotXVal);
        const z1 = ry * Math.sin(rotXVal) + rz * Math.cos(rotXVal);

        // Apply continuous dynamic rotation on Y boundary
        const rotYVal = currentYRotation + extraYRotation;
        const x2 = rx * Math.cos(rotYVal) + z1 * Math.sin(rotYVal);
        const z2 = -rx * Math.sin(rotYVal) + z1 * Math.cos(rotYVal);

        const fov = 950;
        const scale = fov / (fov + z2);

        // Gravitational magnetic warping relative to cursor offset
        let finalX = x2;
        let finalY = y1;
        
        if (mouseRef.current.active) {
          const nodeScreenX = centerX + x2 * scale;
          const nodeScreenY = centerY + y1 * scale;
          const mDx = mouseRef.current.x - nodeScreenX;
          const mDy = mouseRef.current.y - nodeScreenY;
          const distanceToMouse = Math.hypot(mDx, mDy);

          if (distanceToMouse < 150) {
            const magnetism = (150 - distanceToMouse) / 150;
            // Draw coordinate net node slightly toward the cursor positions
            finalX -= (mDx / distanceToMouse) * magnetism * 24;
            finalY -= (mDy / distanceToMouse) * magnetism * 24;
          }
        }

        const projX = centerX + finalX * scale;
        const projY = centerY + finalY * scale;

        projectedGlobe.push({
          projX,
          projY,
          scale,
          z: z2,
          color: p.color,
          size: p.size,
        });
      }

      // Sort by depth for correct opacity overlap visual layering
      projectedGlobe.sort((a, b) => b.z - a.z);

      // Render web connections among dense globe points
      ctx.lineWidth = 0.55;
      for (let i = 0; i < projectedGlobe.length; i += 3) {
        const p1 = projectedGlobe[i];
        if (p1.z > 50) continue; // Skip backside points for visual clarity

        let conSlots = 0;
        for (let j = i + 1; j < projectedGlobe.length; j++) {
          const p2 = projectedGlobe[j];
          if (Math.abs(p1.z - p2.z) > 45) continue;

          const distanceBetween = Math.hypot(p1.projX - p2.projX, p1.projY - p2.projY);
          if (distanceBetween < 40) {
            const alphaVal = Math.min(0.26, (40 - distanceBetween) / 40) * (1 - (p1.z / radius));
            if (alphaVal > 0) {
              ctx.strokeStyle = `rgba(6, 182, 212, ${alphaVal.toFixed(2)})`;
              ctx.beginPath();
              ctx.moveTo(p1.projX, p1.projY);
              ctx.lineTo(p2.projX, p2.projY);
              ctx.stroke();
              conSlots++;
            }
          }
          if (conSlots >= 2) break;
        }
      }

      // Render the actual shining globe star particles
      for (let i = 0; i < projectedGlobe.length; i++) {
        const p = projectedGlobe[i];
        const opacityVal = Math.max(0.12, Math.min(1.0, 1 - (p.z + radius) / (radius * 1.95)));

        // Spark and glow on important Luminous nodes
        if (p.size >= 2.0) {
          ctx.shadowBlur = 6;
          ctx.shadowColor = "rgba(34, 211, 238, 0.75)";
        } else {
          ctx.shadowBlur = 0;
        }

        ctx.fillStyle = p.color.replace(/[\d.]+\)$/, `${opacityVal.toFixed(2)})`);
        ctx.beginPath();
        ctx.arc(p.projX, p.projY, p.size * p.scale, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.shadowBlur = 0; // reset shadow configurations

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener("resize", handleResize);
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseleave", onMouseLeave);
      window.removeEventListener("touchmove", onTouchMove);
    };
  }, []);

  return (
    <canvas 
      ref={canvasRef} 
      className="fixed inset-0 w-full h-full block pointer-events-none z-0 bg-[#030712] transition-opacity duration-1000" 
      style={{ mixBlendMode: "screen" }}
    />
  );
}
