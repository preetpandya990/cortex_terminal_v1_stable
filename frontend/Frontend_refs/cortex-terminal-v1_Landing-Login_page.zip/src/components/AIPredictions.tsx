import React, { useState, useEffect } from "react";
import { 
  TrendingUp, 
  TrendingDown, 
  Cpu, 
  Clock, 
  RefreshCw, 
  ArrowUpRight, 
  ArrowDownRight,
  Activity,
  DollarSign,
  Briefcase
} from "lucide-react";
import { Asset } from "../types";

interface AIPredictionsProps {
  currentAsset: Asset;
  onTrade: (type: "BUY" | "SELL", price: number) => void;
  balance: number;
}

export default function AIPredictions({ currentAsset, onTrade, balance }: AIPredictionsProps) {
  const [timeRange, setTimeRange] = useState<string>("24 Hours");
  const [analysisText, setAnalysisText] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);
  const [tradeAmount, setTradeAmount] = useState<string>("0.1");

  const runAnalysis = async () => {
    setLoading(true);
    setAnalysisText("");
    try {
      const response = await fetch("/api/terminal/market-analysis", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ assetSign: currentAsset.symbol, timeRange }),
      });
      const data = await response.json();
      setAnalysisText(data.analysis || "Could not retrieve quantum metrics. Re-syncing signal.");
    } catch {
      setAnalysisText("Core diagnostic failure. Reconnect local prediction loops.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    runAnalysis();
  }, [currentAsset.symbol, timeRange]);

  // Simple local historical line generation
  const linePoints = currentAsset.history.map((val, idx) => {
    const x = (idx / (currentAsset.history.length - 1)) * 100;
    const minVal = Math.min(...currentAsset.history) * 0.99;
    const maxVal = Math.max(...currentAsset.history) * 1.01;
    const range = maxVal - minVal;
    const y = 100 - ((val - minVal) / (range || 1)) * 100;
    return `${x},${y}`;
  }).join(" ");

  const isPositive = currentAsset.change >= 0;

  return (
    <div id="ai-predictions-module" className="bg-[#0b1329]/60 backdrop-blur-xl border border-cyan-500/10 rounded-xl p-5 flex flex-col gap-5 self-stretch">
      {/* Top Banner Asset Information */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-cyan-500/10 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-display font-medium text-lg text-white">{currentAsset.name}</span>
            <span className="font-mono text-xs bg-cyan-950 text-cyan-400 px-2 py-0.5 rounded border border-cyan-500/25">
              {currentAsset.symbol}/USD
            </span>
          </div>
          <p className="font-mono text-xs text-gray-400 mt-1">
            Vol: {currentAsset.volume} | Cap: {currentAsset.cap}
          </p>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-right">
            <div className="font-mono text-xl font-bold text-cyan-400 leading-none">
              ${currentAsset.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className={`font-mono text-xs font-semibold flex items-center justify-end gap-1 mt-1 ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
              {isPositive ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
              {isPositive ? "+" : ""}{currentAsset.change}%
            </div>
          </div>

          <button 
            id="ref-metrics-btn"
            onClick={runAnalysis} 
            disabled={loading}
            className="p-2.5 bg-cyan-950/40 hover:bg-cyan-900/40 rounded-lg border border-cyan-500/20 text-cyan-400 transition-all cursor-pointer disabled:opacity-40"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Grid containing Chart and Signal Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Dynamic Glowing Vector Chart */}
        <div className="flex flex-col gap-3 min-h-[220px] bg-slate-950/50 rounded-lg p-4 border border-cyan-500/5 relative overflow-hidden">
          <div className="absolute inset-0 cyber-grid opacity-30 pointer-events-none" />
          <div className="flex items-center justify-between z-10">
            <span className="font-mono text-xs text-gray-400 flex items-center gap-1.5 font-semibold">
              <Activity className="w-3.5 h-3.5 text-cyan-400" /> DYNAMIC QUANT TREND
            </span>
            <div className="flex gap-1">
              {["1H", "24H", "7D"].map((r) => (
                <button
                  id={`time-btn-${r}`}
                  key={r}
                  onClick={() => setTimeRange(r === "1H" ? "1 Hour" : r === "24H" ? "24 Hours" : "7 Days")}
                  className={`font-mono text-[10px] px-2 py-1 rounded transition-all cursor-pointer ${
                    (r === "1H" && timeRange === "1 Hour") || 
                    (r === "24H" && timeRange === "24 Hours") || 
                    (r === "7D" && timeRange === "7 Days")
                      ? "bg-cyan-400 text-slate-950 font-bold"
                      : "text-cyan-400 hover:bg-cyan-950/40"
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          {/* SVG line graph representing asset trends */}
          <div className="flex-1 w-full h-[120px] relative mt-2 z-10">
            <svg className="w-full h-full overflow-visible" preserveAspectRatio="none" viewBox="0 0 100 100">
              {/* Fill Area Gradient */}
              <defs>
                <linearGradient id="chartGlow" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.25" />
                  <stop offset="100%" stopColor="#22d3ee" stopOpacity="0.0" />
                </linearGradient>
              </defs>
              
              {/* Grid Lines */}
              <line x1="0" y1="25" x2="100" y2="25" stroke="rgba(6,182,212,0.06)" strokeWidth="0.5" />
              <line x1="0" y1="50" x2="100" y2="50" stroke="rgba(6,182,212,0.06)" strokeWidth="0.5" />
              <line x1="0" y1="75" x2="100" y2="75" stroke="rgba(6,182,212,0.06)" strokeWidth="0.5" />

              {/* Area */}
              <path
                d={`M 0,100 L ${linePoints} L 100,100 Z`}
                fill="url(#chartGlow)"
              />
              
              {/* Plot points line */}
              <polyline
                fill="none"
                stroke={isPositive ? "#10b981" : "#f43f5e"}
                strokeWidth="1.5"
                points={linePoints}
                className="drop-shadow-[0_0_4px_currentColor]"
              />
            </svg>

            {/* Price labels */}
            <div className="absolute top-1 right-1 font-mono text-[9px] text-gray-500">
              H: ${currentAsset.high.toLocaleString()}
            </div>
            <div className="absolute bottom-1 right-1 font-mono text-[9px] text-gray-500">
              L: ${currentAsset.low.toLocaleString()}
            </div>
          </div>

          {/* Ticker Ledger stats */}
          <div className="grid grid-cols-2 gap-3 mt-1 pt-3 border-t border-cyan-500/5 z-10 w-full">
            <div className="bg-slate-950/40 p-2 rounded border border-cyan-500/5 flex flex-col">
              <span className="font-mono text-[10px] text-gray-400">SESSION EXTREMUMS</span>
              <span className="font-mono text-xs font-bold text-white mt-1">
                ${currentAsset.low.toLocaleString()} - ${currentAsset.high.toLocaleString()}
              </span>
            </div>
            <div className="bg-slate-950/40 p-2 rounded border border-cyan-500/5 flex flex-col">
              <span className="font-mono text-[10px] text-gray-400">24H TRADED VOL.</span>
              <span className="font-mono text-xs font-bold text-white mt-1">
                {currentAsset.volume}
              </span>
            </div>
          </div>
        </div>

        {/* Local Executative Order placement */}
        <div className="flex flex-col gap-4 bg-slate-950/50 p-4 rounded-lg border border-cyan-500/5 relative overflow-hidden">
          <div className="absolute inset-0 cyber-grid opacity-30 pointer-events-none" />
          <span className="font-mono text-xs text-gray-400 flex items-center gap-1.5 font-semibold z-10">
            <Briefcase className="w-3.5 h-3.5 text-cyan-400" /> ORDER EXECUTION SECTOR
          </span>

          <div className="flex-1 flex flex-col justify-center gap-4 z-10">
            <div className="flex justify-between items-center bg-slate-950/80 p-3 rounded border border-cyan-500/10">
              <div className="flex flex-col">
                <span className="font-mono text-[10px] text-gray-400">LIQUID COLLATERAL</span>
                <span className="font-mono text-sm font-bold text-cyan-400 mt-1">
                  ${balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="text-right">
                <span className="font-mono text-[10px] text-gray-400">POSITION HELD</span>
                <span className="font-mono text-sm font-bold text-white mt-1 block">
                  0.00 {currentAsset.symbol}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <label id="order-qty-label" htmlFor="qty-input" className="font-mono text-[10px] text-gray-400">ORDER QUANTITY ({currentAsset.symbol})</label>
              <div className="flex items-center gap-2">
                <input
                  id="qty-input"
                  type="number"
                  min="0.001"
                  step="0.1"
                  value={tradeAmount}
                  onChange={(e) => setTradeAmount(e.target.value)}
                  className="bg-slate-950 border border-cyan-500/20 rounded px-3 py-2 font-mono text-sm text-cyan-300 focus:outline-none focus:border-cyan-400 flex-1"
                />
                <button
                  id="max-qty-btn"
                  onClick={() => {
                    const maxUnits = balance / currentAsset.price;
                    setTradeAmount(Math.max(0.001, parseFloat(maxUnits.toFixed(4))).toString());
                  }}
                  className="px-3 py-2 bg-cyan-950/40 hover:bg-cyan-900/40 border border-cyan-500/20 text-cyan-400 rounded font-mono text-xs transition-all cursor-pointer"
                >
                  MAX
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 mt-1">
              <button
                id="trade-buy-btn"
                onClick={() => {
                  const qty = parseFloat(tradeAmount);
                  if (qty > 0) onTrade("BUY", qty);
                }}
                className="py-2.5 bg-emerald-500/10 hover:bg-emerald-500/25 border border-emerald-500/40 hover:border-emerald-400 text-emerald-400 font-display font-medium rounded transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <TrendingUp className="w-4 h-4" /> SECURE BUY
              </button>
              <button
                id="trade-sell-btn"
                onClick={() => {
                  const qty = parseFloat(tradeAmount);
                  if (qty > 0) onTrade("SELL", qty);
                }}
                className="py-2.5 bg-rose-500/10 hover:bg-rose-500/25 border border-rose-500/40 hover:border-rose-400 text-rose-400 font-display font-medium rounded transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <TrendingDown className="w-4 h-4" /> SECURE SELL
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* AI Market commentary analysis stream */}
      <div className="bg-slate-950/40 rounded-lg p-4 border border-cyan-500/10 relative overflow-hidden flex flex-col gap-2.5">
        <div className="absolute inset-0 cyber-grid opacity-15 pointer-events-none" />
        <div className="flex items-center justify-between pb-2 border-b border-cyan-500/5 z-10">
          <span className="font-mono text-xs text-white flex items-center gap-1.5 font-bold">
            <Cpu className="w-3.5 h-3.5 text-cyan-400 animate-pulse" /> CORTEX ELITE ANALOGUE REPORT
          </span>
          <span className="font-mono text-[10px] text-cyan-400 flex items-center gap-1">
            <Clock className="w-3 h-3" /> RETIEVED: {timeRange} WINDOW
          </span>
        </div>

        {loading ? (
          <div className="py-8 flex flex-col items-center justify-center gap-3 z-10">
            <RefreshCw className="w-6 h-6 text-cyan-400 animate-spin" />
            <span className="font-mono text-xs text-cyan-400/80 animate-pulse">De-scrambling binary metrics...</span>
          </div>
        ) : (
          <div className="font-sans text-sm text-gray-300 leading-relaxed max-h-[300px] overflow-y-auto z-10 pr-2 whitespace-pre-line">
            {analysisText}
          </div>
        )}
      </div>
    </div>
  );
}
