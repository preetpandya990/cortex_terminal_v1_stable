import React, { useState } from "react";
import { 
  ShieldCheck, 
  Cpu, 
  X, 
  User, 
  Building2, 
  FileText, 
  Lock, 
  HelpCircle,
  AlertCircle
} from "lucide-react";
import { AccessRequestState } from "../types";

interface RequestAccessModalProps {
  onClose: () => void;
  onGrantAccess: (clearanceLevel: string) => void;
}

export default function RequestAccessModal({ onClose, onGrantAccess }: RequestAccessModalProps) {
  const [form, setForm] = useState<AccessRequestState>({
    name: "",
    bio: "",
    targetRole: "L3 Sovereign Trader",
    securityCode: ""
  });
  const [loading, setLoading] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<{ approved?: boolean; clearanceLevel?: string; reason?: string } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.bio) return;

    setLoading(true);
    setFeedback(null);

    try {
      const response = await fetch("/api/terminal/request-access", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const data = await response.json();
      setFeedback(data);

      if (data.approved) {
        // Wait 2.8 seconds to let user read the futuristic gatekeeper acceptance message, then redirect in
        setTimeout(() => {
          onGrantAccess(data.clearanceLevel || "L1_ANALYST");
          onClose();
        }, 2800);
      }
    } catch {
      setFeedback({
        approved: false,
        reason: "[GRID DE-SYNC] Authentication link corrupted. Please configure Gemini API key or try again."
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div id="access-modal-card" className="relative w-full max-w-lg bg-[#070b19] border border-cyan-500/20 rounded-2xl p-6 shadow-2xl overflow-hidden">
        <div className="absolute inset-0 cyber-grid opacity-20 pointer-events-none" />
        <div className="terminal-scanline" />

        {/* Close Button */}
        <button
          id="close-access-modal-btn"
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-gray-500 hover:text-white hover:bg-cyan-950/40 rounded-lg transition-all cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 border-b border-cyan-500/10 pb-4 mb-5">
          <div className="p-2 bg-cyan-950/60 rounded-xl border border-cyan-500/25">
            <Cpu className="w-5 h-5 text-cyan-400 animate-pulse" />
          </div>
          <div>
            <h3 className="font-display font-bold text-lg text-white">ACCESS RECRUITMENT LOG</h3>
            <p className="font-mono text-[10px] text-cyan-400/80">CORTEX GATEKEEPER SUITE v1.0.4</p>
          </div>
        </div>

        {!feedback ? (
          <form onSubmit={handleSubmit} className="flex flex-col gap-4 relative z-10">
            <p className="text-gray-300 text-xs leading-relaxed">
              Cortex Terminal is highly restricted. Complete a creative bio statement or provide a known crypto passkey to request gatekeeper clearance.
            </p>

            {/* Operator Identifier */}
            <div className="flex flex-col gap-1.5">
              <label id="access-name-label" htmlFor="access-name-input" className="font-mono text-[10px] text-cyan-400 flex items-center gap-1">
                <User className="w-3 h-3" /> OPERATOR IDENTIFIER (NAME)
              </label>
              <input
                id="access-name-input"
                type="text"
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Secure handle or alias"
                className="bg-slate-900 border border-cyan-500/20 rounded-lg px-3 py-2 font-mono text-sm text-cyan-300 focus:outline-none focus:border-cyan-400 placeholder-cyan-500/35"
              />
            </div>

            {/* Target Role Designation */}
            <div className="flex flex-col gap-1.5">
              <label id="access-role-label" htmlFor="access-role-select" className="font-mono text-[10px] text-cyan-400 flex items-center gap-1">
                <Building2 className="w-3 h-3" /> TARGET QUANT RECRUITMENT ROLE
              </label>
              <select
                id="access-role-select"
                value={form.targetRole}
                onChange={(e) => setForm({ ...form, targetRole: e.target.value })}
                className="bg-slate-900 border border-cyan-500/20 rounded-lg px-3 py-2 font-mono text-sm text-cyan-300 focus:outline-none focus:border-cyan-400 cursor-pointer"
              >
                <option value="L3 Sovereign Trader">L3 Sovereign Trader (Max Leverage)</option>
                <option value="L2 Quant Mathematician">L2 Quant Analyst / Mathematician</option>
                <option value="L1 Cryptographic Analyst">L1 Cryptographic Researcher</option>
              </select>
            </div>

            {/* Bio Intent */}
            <div className="flex flex-col gap-1.5">
              <label id="access-bio-label" htmlFor="access-bio-text" className="font-mono text-[10px] text-cyan-400 flex items-center gap-1">
                <FileText className="w-3 h-3" /> TRADING INTENT / AI CONVINCING CREDENTIALS
              </label>
              <textarea
                id="access-bio-text"
                required
                rows={3}
                value={form.bio}
                onChange={(e) => setForm({ ...form, bio: e.target.value })}
                placeholder="Describe why you merit access to high-leverage pools. Gemini evaluates this bio signature!"
                className="bg-slate-900 border border-cyan-500/20 rounded-lg px-3 py-2 font-sans text-xs text-cyan-200 focus:outline-none focus:border-cyan-400 placeholder-cyan-500/35 resize-none leading-relaxed"
              />
            </div>

            {/* Cryptographic Secrets Passkey (Optional) */}
            <div className="flex flex-col gap-1.5">
              <label id="access-code-label" htmlFor="access-code-input" className="font-mono text-[10px] text-cyan-400 flex items-center gap-1">
                <Lock className="w-3 h-3" /> KNOWN SECURITY CRYPT-PASSKEY (OPTIONAL)
              </label>
              <input
                id="access-code-input"
                type="password"
                value={form.securityCode}
                onChange={(e) => setForm({ ...form, securityCode: e.target.value })}
                placeholder="e.g. CORTEX-2026 for instant entrance"
                className="bg-slate-900 border border-cyan-500/20 rounded-lg px-3 py-2 font-mono text-sm text-cyan-300 focus:outline-none focus:border-cyan-400 placeholder-cyan-500/35"
              />
              <span className="font-mono text-[9px] text-gray-500">
                Tip: Enter <span className="text-cyan-400">CORTEX-2026</span> or write a highly analytical bio statement.
              </span>
            </div>

            {/* Action buttons */}
            <button
              id="submit-recruitment-btn"
              type="submit"
              disabled={loading || !form.name || !form.bio}
              className="mt-2 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-slate-950 font-semibold rounded-lg shadow-lg hover:shadow-cyan-500/10 cursor-pointer transition-all flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {loading ? (
                <>
                  <Cpu className="w-4 h-4 animate-spin" /> ANALYZING BIOMETRICS...
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" /> TRANSMIT REQUEST PACKET
                </>
              )}
            </button>
          </form>
        ) : (
          <div className="flex flex-col items-center text-center gap-4 py-6 relative z-10">
            {feedback.approved ? (
              <>
                <div className="p-3 bg-emerald-950/80 border border-emerald-500/30 text-emerald-400 rounded-full animate-bounce">
                  <ShieldCheck className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="font-display font-black text-emerald-400 text-lg">CLEARANCE STATE: GRANTED</h4>
                  <p className="font-mono text-[9px] text-cyan-400 mt-0.5">LEVEL: {feedback.clearanceLevel}</p>
                </div>
                <div className="bg-emerald-950/30 border border-emerald-500/10 p-3.5 rounded-xl max-w-sm text-xs text-emerald-300 leading-relaxed font-sans">
                  {feedback.reason}
                </div>
                <span className="font-mono text-[10px] text-cyan-400/80 animate-pulse mt-2 flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5 animate-spin" /> Directing neural port streams...
                </span>
              </>
            ) : (
              <>
                <div className="p-3 bg-rose-950/80 border border-rose-500/30 text-rose-400 rounded-full">
                  <AlertCircle className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="font-display font-black text-rose-400 text-lg">CLEARANCE STATE: DECLINED</h4>
                  <p className="font-mono text-[9px] text-rose-500 mt-0.5">REF: COGNITIVE_SIGN_MISMATCH</p>
                </div>
                <div className="bg-rose-950/30 border border-rose-500/10 p-3.5 rounded-xl max-w-sm text-xs text-rose-300 leading-relaxed font-sans">
                  {feedback.reason}
                </div>
                <button
                  id="retry-recruitment-btn"
                  onClick={() => setFeedback(null)}
                  className="mt-2 text-xs bg-slate-900 border border-cyan-500/25 text-cyan-400 hover:text-white hover:bg-cyan-950 px-4 py-2 rounded-lg cursor-pointer transition-all"
                >
                  RE-WRITE BIO APPLICATION
                </button>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
