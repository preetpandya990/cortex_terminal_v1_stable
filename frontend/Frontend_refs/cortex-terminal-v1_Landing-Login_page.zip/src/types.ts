export interface Asset {
  symbol: string;
  name: string;
  price: number;
  change: number;
  history: number[];
  high: number;
  low: number;
  volume: string;
  cap: string;
}

export interface Message {
  id: string;
  role: "user" | "model" | "system";
  content: string;
  timestamp: Date;
}

export interface TradeOrder {
  id: string;
  timestamp: string;
  symbol: string;
  type: "BUY" | "SELL";
  price: number;
  amount: number;
  total: number;
}

export interface AccessRequestState {
  name: string;
  bio: string;
  targetRole: string;
  securityCode: string;
}

export interface AccessResponseState {
  approved: boolean;
  clearanceLevel: string;
  reason: string;
  token?: string;
}
